<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
	'Twilio' => 'Twilio',
        'LBL_TWILIO_SMS' => 'Twilio SMS',
        'LBL_SEND_SMS' => 'Send SMS',
        'LBL_SMS_INFORMATION' => 'SMS Information',
        'LBL_SMS_TO' => 'SMS To',
        'LBL_SMS_BODY' => 'Message Text',
        'LBL_TWILIO_CALL' => 'Twilio Call',
        'LBL_CALL' => 'Make Call',
        'LBL_CALL_INFORMATION' => 'CALL Information',
        'LBL_CALL_TO' => 'Call To',
        'LBL_CALL_BODY' => 'Message',
	
);

?>
